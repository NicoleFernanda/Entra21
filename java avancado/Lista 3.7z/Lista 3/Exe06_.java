package lista3;

import java.util.Scanner;

public class Exe06_ {
	
	Scanner tec = new Scanner(System.in);
	
	private char jogo[][] = new char[3][3];
	private byte contador = 2;
    private char jogada;
    private char simbolo;
    private boolean valida = false;
    private boolean ganhou = false;
    private byte ganhador = 0; //jogador 1 ou 2;
    private byte velha = 1;

    Exe06_() {
        Preenchermapa(jogo);
        imprime(jogo);
    }
	
	public void Preenchermapa(char jogo[][]) {
		this.jogo[0][0] = '1'; this.jogo[0][1] = '2'; this.jogo[0][2] = '3';
        this.jogo[1][0] = '4'; this.jogo[1][1] = '5'; this.jogo[1][2] = '6';
        this.jogo[2][0] = '7'; this.jogo[2][1] = '8'; this.jogo[2][2] = '9';
	}
	
	public void imprime(char jogo[][]) {
        System.out.println("-------------");
        
        for (int i = 0; i < this.jogo.length; i++) {
            System.out.print("| ");

            for (int j = 0; j < this.jogo[i].length; j++) {
                System.out.print(this.jogo[i][j] + " " + "|" + " ");
            }
            
            System.out.println();
        }

        System.out.println("-------------");
	}
	
	public void jogar() {
		
		while (true) {

            if (this.ganhou == true) {
                System.out.println("jogador [" + this.ganhador + "] ganhou!");
                break;
            }

            valida = false;
			System.out.print("vez do ");
        	if (this.contador % 2 == 0) {//1
				System.out.println("jogador 1 : ");
				this.jogada = tec.next().charAt(0);
				this.simbolo = 'X';
			} else {//2
				System.out.println("jogador 2 : ");
				this.jogada = tec.next().charAt(0);
				this.simbolo = 'O';
			}
		
        	for (int i = 0; i < this.jogo.length; i++) {//3/3
				if (this.valida == true) {
                    break;
                }
        		for (int j = 0; j < jogo.length; j++) {//2/3
					
        			if (this.jogo[i][j] == this.jogada) {//valido ; contador++
        				this.jogo[i][j] = this.simbolo;
        				System.out.println("-------------");
        
                        for (int k = 0; k < this.jogo.length; k++) {
                            System.out.print("| ");

                            for (int h = 0; h < this.jogo[k].length; h++) {
                                System.out.print(this.jogo[k][h] + " " + "|" + " ");
                            }      
            
                            System.out.println();
                        }

                    System.out.println("-------------");
        				
        				this.valida = true;
        				this.contador++;
        				break;
						
					} else {//jogue novamente
						this.valida = false;
					}
				
        		
        		
        		}//fim for 2/3
        		
			}//fim for 3/3
        
        
        	if (this.valida == false) {
        		System.out.println("jogada invalida");
        	}

            if (this.jogo[0][0] == this.jogo[0][1]  && this.jogo[0][0] == this.jogo[0][2]) {
                this.ganhou = true;
                if (this.jogo[0][0] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][0] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[1][0] == this.jogo[1][1]  && this.jogo[1][0] == this.jogo[1][2]){
                this.ganhou = true;
                if (this.jogo[1][0] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[1][0] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[2][0] == this.jogo[2][1]  && this.jogo[2][0] == this.jogo[2][2]){
                this.ganhou = true;
                if (this.jogo[2][0] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[2][0] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[0][0] == this.jogo[1][0]  && this.jogo[0][0] == this.jogo[2][0]){
                this.ganhou = true;
                if (this.jogo[0][0] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][0] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[0][1] == this.jogo[1][1]  && this.jogo[0][1] == this.jogo[2][1]) {
                this.ganhou = true;
                if (this.jogo[0][1] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][1] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[0][2] == this.jogo[1][2]  && this.jogo[1][2] == this.jogo[2][2]) {
                this.ganhou = true;
                if (this.jogo[0][2] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][2] == 'O'){
                    this.ganhador = 2;
                }

            } else if (this.jogo[0][0] == this.jogo[1][1]  && this.jogo[1][1] == jogo[2][2]) {
                this.ganhou = true;
                if (this.jogo[0][0] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][0] == 'O'){
                    this.ganhador = 2;
                }
            } else if (jogo[0][2] == jogo[1][1]  && jogo[0][2] == jogo[2][0]) {
                this.ganhou = true;
                if (this.jogo[0][2] == 'X') {
                    this.ganhador = 1;//jogador 1
                } else if (this.jogo[0][2] == 'O'){
                    this.ganhador = 2;
                }
            } else if (this.velha == 10) {
                System.out.println("EMPATOU");
                break;
            } else {
                this.ganhou = false;
            }
            
            this.velha++;
	
		}//fim while

	}

    public char[][] getJogo() {
        return jogo;
    }

    public void setJogo(char[][] jogo) {
        this.jogo = jogo;
    }

    public byte getContador() {
        return contador;
    }

    public void setContador(byte contador) {
        this.contador = contador;
    }

    public char getJogada() {
        return jogada;
    }

    public void setJogada(char jogada) {
        this.jogada = jogada;
    }

    public char getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(char simbolo) {
        this.simbolo = simbolo;
    }

    public boolean isValida() {
        return valida;
    }

    public void setValida(boolean valida) {
        this.valida = valida;
    }

    public boolean isGanhou() {
        return ganhou;
    }

    public void setGanhou(boolean ganhou) {
        this.ganhou = ganhou;
    }

    public byte getGanhador() {
        return ganhador;
    }

    public void setGanhador(byte ganhador) {
        this.ganhador = ganhador;
    }

    public byte getVelha() {
        return velha;
    }

    public void setVelha(byte velha) {
        this.velha = velha;
    }

    

}