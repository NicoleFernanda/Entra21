package lista3;

public class Exe06_exemplo {
    public static void main(String[] args) {
        Exe06_ jogando = new Exe06_();
        jogando.jogar();
    }
}
