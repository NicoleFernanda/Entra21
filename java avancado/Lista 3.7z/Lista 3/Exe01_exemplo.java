package lista3;

public class Exe01_exemplo {
    public static void main(String[] args) {
        
        Exe01_ lampada = new Exe01_(false);
        lampada.ligar(lampada.ligada);
        lampada.desligar(lampada.ligada);

        
    }
}
